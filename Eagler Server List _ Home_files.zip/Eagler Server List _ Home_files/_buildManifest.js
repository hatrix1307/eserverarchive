var _____WB$wombat$assign$function_____=function(name){return (self._wb_wombat && self._wb_wombat.local_init && self._wb_wombat.local_init(name))||self[name];};if(!self.__WB_pmw){self.__WB_pmw=function(obj){this.__WB_source=obj;return this;}}{
let window = _____WB$wombat$assign$function_____("window");
let self = _____WB$wombat$assign$function_____("self");
let document = _____WB$wombat$assign$function_____("document");
let location = _____WB$wombat$assign$function_____("location");
let top = _____WB$wombat$assign$function_____("top");
let parent = _____WB$wombat$assign$function_____("parent");
let frames = _____WB$wombat$assign$function_____("frames");
let opens = _____WB$wombat$assign$function_____("opens");
self.__BUILD_MANIFEST=function(s,c,e,a,t,i,d,n,b,r,f,u,k,h,j,p){return{__rewrites:{afterFiles:[],beforeFiles:[],fallback:[]},"/":[s,c,"static/css/76289acd00d625c1.css","static/chunks/pages/index-033e20d615a60f0f.js"],"/404":[e,s,a,t,c,i,"static/chunks/pages/404-a88caf76bc70ff0b.js"],"/_error":["static/chunks/pages/_error-85094e3a347bebb8.js"],"/admin":[e,s,a,t,"static/chunks/69480c19-08c67d375bd497dc.js","static/chunks/257e8032-8ff7a41228e0ee48.js","static/chunks/5727625e-ba799e444368c0a2.js",c,"static/css/a2d1a7706a50f3ce.css","static/chunks/pages/admin-2eebb954b5f61407.js"],"/admin/users":[e,s,a,t,c,n,"static/css/bf2b6566143b01b8.css","static/chunks/pages/admin/users-003444c53bafa210.js"],"/forget_me":[e,s,a,t,c,"static/css/3675ba4c67407a79.css","static/chunks/pages/forget_me-fa76f34370a51c9a.js"],"/news":[e,s,a,t,c,b,r,f,"static/chunks/pages/news-c883d2c7ba70b781.js"],"/news/new":[e,s,a,t,u,c,k,"static/chunks/pages/news/new-34fef54268746f85.js"],"/news/[id]":[e,s,a,t,c,b,r,f,"static/chunks/pages/news/[id]-fbee75b5c823c0c6.js"],"/news/[id]/edit":[e,s,a,t,u,c,k,"static/chunks/pages/news/[id]/edit-ac1f5d01c3d9dfb9.js"],"/privacy":[e,s,a,t,c,i,"static/chunks/pages/privacy-70334a7230fc152e.js"],"/profile":[e,s,a,t,c,"static/css/1c6e00d1273c0dc3.css","static/chunks/pages/profile-e1d4b08b4d861710.js"],"/servers":[e,s,a,t,c,n,"static/css/a8a9e92b13163f11.css","static/chunks/pages/servers-371dec6447e0e0f9.js"],"/servers/new":[e,s,a,t,h,j,c,d,p,"static/css/0932096658efdca3.css","static/chunks/pages/servers/new-7f0515572c63d5a8.js"],"/servers/[id]":["static/css/4d58c923eeda897e.css","static/chunks/pages/servers/[id]-c059f934b91ffb8e.js"],"/servers/[id]/edit":[e,s,h,j,c,d,p,"static/css/873b5227a1f1ffae.css","static/chunks/pages/servers/[id]/edit-95238f6179350f08.js"],"/tos":[e,s,a,t,c,i,"static/chunks/pages/tos-7bb1c030f0077eec.js"],"/users/[id]":["static/css/c6644d2b711ecae0.css","static/chunks/pages/users/[id]-b3814d9859cdb1be.js"],"/verify":[e,s,a,t,c,d,"static/css/d7a161341c1b5ae1.css","static/chunks/pages/verify-2710cfa5f86a40aa.js"],sortedPages:["/","/404","/_app","/_error","/admin","/admin/users","/forget_me","/news","/news/new","/news/[id]","/news/[id]/edit","/privacy","/profile","/servers","/servers/new","/servers/[id]","/servers/[id]/edit","/tos","/users/[id]","/verify"]}}("static/chunks/fea29d9f-d16b76c7627e8f91.js","static/chunks/3695-b04646389324c989.js","static/chunks/85d7bc83-4d29bd1c4681b3ef.js","static/chunks/75fc9c18-7b7a1972fe9d28a9.js","static/chunks/41155975-f293fcc8a7280f75.js","static/css/ed04dedc6d2efcf6.css","static/chunks/1208-9391865bbf59a613.js","static/chunks/700-8a2b49e8d81d2cd5.js","static/chunks/4526-8d2144efe8b07408.js","static/chunks/9599-6e4e23802794fa40.js","static/css/7043c7777c759221.css","static/chunks/ebc70433-2beddcaf0a21c10e.js","static/css/60e054316b7d65e6.css","static/chunks/e21e5bbe-fde1231973188e8d.js","static/chunks/5d416436-61c0c4bf681fbe86.js","static/chunks/1867-f35ce1e167ccf37e.js"),self.__BUILD_MANIFEST_CB&&self.__BUILD_MANIFEST_CB();
}
/*
     FILE ARCHIVED ON 16:24:18 Dec 27, 2025 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 16:25:55 Dec 27, 2025.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  captures_list: 0.81
  exclusion.robots: 0.022
  exclusion.robots.policy: 0.014
  esindex: 0.007
  cdx.remote: 9.019
  LoadShardBlock: 94.355 (3)
  PetaboxLoader3.datanode: 84.433 (3)
  PetaboxLoader3.resolve: 7.991
  load_resource: 20.034
*/