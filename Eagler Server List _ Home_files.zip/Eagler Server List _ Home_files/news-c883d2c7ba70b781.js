var _____WB$wombat$assign$function_____=function(name){return (self._wb_wombat && self._wb_wombat.local_init && self._wb_wombat.local_init(name))||self[name];};if(!self.__WB_pmw){self.__WB_pmw=function(obj){this.__WB_source=obj;return this;}}{
let window = _____WB$wombat$assign$function_____("window");
let self = _____WB$wombat$assign$function_____("self");
let document = _____WB$wombat$assign$function_____("document");
let location = _____WB$wombat$assign$function_____("location");
let top = _____WB$wombat$assign$function_____("top");
let parent = _____WB$wombat$assign$function_____("parent");
let frames = _____WB$wombat$assign$function_____("frames");
let opens = _____WB$wombat$assign$function_____("opens");
(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[6134],{2616:function(e,t,n){(window.__NEXT_P=window.__NEXT_P||[]).push(["/news",function(){return n(4140)}])},4140:function(e,t,n){"use strict";n.r(t),n.d(t,{default:function(){return f}});var s=n(5893),r=n(9008),i=n.n(r),o=n(4609),c=n.n(o),l=n(5924),a=n(818),d=n(7294),u=n(3695),h=n(8857),p=n(3651),x=n(2669),w=n(1163),j=n(788),m=n(5124);function f(){let{user:e}=(0,a.a)(),t=(0,w.useRouter)(),[n,r]=(0,d.useState)(null),[o,f]=(0,d.useState)(!0),g=(0,p.l)();return(0,d.useEffect)(()=>{x.Z.getNews().then(e=>{r(e.data),f(!1)}).catch(e=>{g({type:"error",content:"Failed to load news."}),f(!1)})},[e]),(0,s.jsxs)(s.Fragment,{children:[(0,s.jsxs)(i(),{children:[(0,s.jsx)("title",{children:"Eagler Server List | Site News"}),(0,s.jsx)("meta",{name:"viewport",content:"width=device-width, initial-scale=1, shrink-to-fit=no"}),(0,s.jsx)("meta",{httpEquiv:"x-ua-compatible",content:"ie=edge"}),(0,s.jsx)("meta",{property:"og:description",content:"The brand new, rewritten Eaglercraft server list. Built from the ground up to be more secure and elegant."}),(0,s.jsx)("meta",{property:"twitter:description",content:"The brand new, rewritten Eaglercraft server list. Built from the ground up to be more secure and elegant."}),(0,s.jsx)("meta",{property:"theme-color",content:"#FB8464"}),(0,s.jsx)("meta",{property:"og:title",content:"Eagler Server List - Your Servers"}),(0,s.jsx)("meta",{property:"og:type",content:"website"}),(0,s.jsx)("link",{rel:"icon",href:"/favicon.ico"})]}),(0,s.jsxs)("div",{children:[(0,s.jsx)(l.default,{}),(0,s.jsxs)("div",{className:c().homeRoot,children:[(0,s.jsx)("h1",{className:c().row,children:"Site News"}),(0,s.jsx)("p",{children:"View updates about the site."}),o?(0,s.jsx)(h.T,{}):(0,s.jsx)(s.Fragment,{children:n&&n.length>0?(0,s.jsxs)("div",{style:{display:"flex",flexDirection:"column",alignItems:"center",gap:"20px"},children:[[].concat(n).sort((e,t)=>e.postedAt<t.postedAt?1:-1).map((e,t)=>(0,s.jsx)(m.Z,{newsPost:e,inline:!0},t)),e&&e.roles.some(e=>["ADMIN","DEVELOPER"].includes(e))&&(0,s.jsx)(u.Z,{startIcon:(0,s.jsx)(j.ePA,{}),onClick:()=>t.push("/news/new"),children:"Add New Post"})]}):(0,s.jsxs)("div",{className:c().center,children:[(0,s.jsx)("h1",{children:"Nothing here yet"}),(0,s.jsx)("p",{children:"There are currently no news updates."}),e&&e.roles.some(e=>["ADMIN","DEVELOPER"].includes(e))&&(0,s.jsx)(u.Z,{startIcon:(0,s.jsx)(j.ePA,{}),onClick:()=>t.push("/news/new"),children:"Add New Post"})]})})]})]})]})}}},function(e){e.O(0,[8127,4838,4885,4396,3695,4526,9599,2888,9774,179],function(){return e(e.s=2616)}),_N_E=e.O()}]);
}
/*
     FILE ARCHIVED ON 19:26:04 Dec 13, 2025 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 16:21:46 Dec 27, 2025.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  captures_list: 0.842
  exclusion.robots: 0.036
  exclusion.robots.policy: 0.022
  esindex: 0.013
  cdx.remote: 11.186
  LoadShardBlock: 97.833 (3)
  PetaboxLoader3.datanode: 138.513 (5)
  load_resource: 168.124 (2)
  PetaboxLoader3.resolve: 123.139 (2)
*/